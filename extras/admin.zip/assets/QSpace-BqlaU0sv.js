import{l as a,h as s}from"./index-SudMGMLw.js";const p=a({name:"QSpace",setup(){const e=s("div",{class:"q-space"});return()=>e}});export{p as Q};
