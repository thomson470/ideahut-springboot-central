import{h as e,l as a}from"./index.163e81c6.js";const p=e("div",{class:"q-space"});var c=a({name:"QSpace",setup(){return()=>p}});export{c as Q};
